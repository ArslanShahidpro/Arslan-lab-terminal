 export const firebaseConfig = {
     apiKey: "AIzaSyAZoREdtbOO1_Hw3axhzFGZakQv0B04o8E",
    authDomain: "asssssssssss-d196a.firebaseapp.com",
    databaseURL: "https://asssssssssss-d196a-default-rtdb.firebaseio.com",
    projectId: "asssssssssss-d196a",
    storageBucket: "asssssssssss-d196a.appspot.com",
    messagingSenderId: "839284142202",
    appId: "1:839284142202:web:505f66c8194bfb89e68bc3",
    measurementId: "G-QQRFEXZMM6",
     };
